from __future__ import print_function
import argparse
import boto3
import json
import process_instances
import process_roles
import process_groups
import process_users
import process_policies
import psycopg2
import sys, os

def parse_arguments():
    audit = "local"
    parser = argparse.ArgumentParser()
    parser.add_argument("-a", "--audit", help="audit [all (default), local, remote] AWS Account(s)")
    args = parser.parse_args()
    if args.audit == "local":
        print("Auditing local")
        audit="local"
    elif args.audit == "remote":
        print("Auditing remote, skipping local")
        audit="remote"
    else:
        print("Auditing all")
        audit="all"
    return audit;

def connect_to_db():
    print ("Connecting to database")
    try:
        connstring = "dbname='" + os.environ['dbname'] + "' user='" + os.environ['dbuser'] + "' host='" + os.environ['dbhost'] + "' password='" + os.environ['dbpass'] + "'"
        conn = psycopg2.connect(connstring)
        cur = conn.cursor()
        conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
    except psycopg2.DatabaseError, exception:
        print (exception)
        sys.exit(1)
    print ("Database connection successful")
    return cur, conn;

def grab_summary(cur):
    print ("Generate summary")
    try:
        cur.execute("select * from view_cloud_audit_review")
    except psycopg2.DatabaseError, exception:
        print (exception)
        sys.exit(1)
    totals = cur.fetchall()
    summary_json = json_dumps(totals)
    return summary_json;

def grab_roles(cur):
    try:
        cur.execute("SELECT aws_account_id, role_arn from aws_cross_account_roles")
    except psycopg2.DatabaseError, exception:
        print (exception)
        sys.exit(1)
    roles = cur.fetchall()
    return roles;

def process_remote(cur, account, arn, session, process_item):
    # need to accept AssumeRole session variable, grab the keys, and run a 
    #   data collection session
    # Update the cross account table and indicate we've used this account now and it's working
    try:
        cur.execute("UPDATE aws_cross_account_roles set working = %s, last_used_ts = %s "
                "where role_arn = %s", (True, "now()", arn))
    except psycopg2.DatabaseError, exception:
        print (exception)
        sys.exit(1)
    try:
        thisiam = boto3.client('iam',
            aws_access_key_id=session['Credentials']['AccessKeyId'],
            aws_secret_access_key=session['Credentials']['SecretAccessKey'],
            aws_session_token=session['Credentials']['SessionToken'])
    except ClientError as e:
       print (e.response['Error']['Code'])
       sys.exit(1)
    print("Processing AWS Account ID: " + str(account))
    process_aws(thisiam, cur, account, process_item)
    return;

def process_aws(thisiam, cur, account, process_item):
    if (process_item == "process_instances"):
        process_instances.process(thisiam, cur, account)
    if (process_item == "process_roles"):
        process_roles.process(thisiam, cur, account)
    if (process_item == "process_users"):
        process_users.process(thisiam, cur, account)
    if (process_item == "process_groups"):
        process_groups.process(thisiam, cur, account)
    if (process_item == "process_policies"):
        process_policies.process(thisiam, cur, account)
    return;

def process_local(cur, process_item):
    try:
        account = boto3.client('sts').get_caller_identity()['Account']
    except ClientError as e:
       print (e.response['Error']['Code'])
       sys.exit(1)
    print("Processing AWS Account ID: " + str(account))
    try:
        thisiam = boto3.client('iam')
    except ClientError as e:
       print (e.response['Error']['Code'])
       sys.exit(1)
    process_aws(thisiam, cur, account, process_item)
    return;

def lambda_handler(event, context):
    print(json.dumps(event))
    # setup -> all function calls will require database access
    cur = ""
    cur, conn = connect_to_db()
    # default is to audit everything
    audit="all"
    # list of processes
    # create a list of processes: in the future collect this data from a DB
    process_list = [ "process_instances","process_roles","process_users","process_groups", "process_policies"]
   
    # two possible conditions: 
    #   1. NO event data, therefore this run this script needs to push ARNs to 
    #       the SNS topic
    #   2. Event Data, including a Cross Account Role ARN & item to process
    #       In this case, we need to use the ARN to execute the $PROCESS requested
    value = event.get('rolearn')
    if value is None:
        # new normal process -> generate rolearns and put them in the SNS topic
        print("Collecting ARNs, pushing them to SNS")
        print ("Process Accounts in Database")
        roles = grab_roles(cur)
        print (roles)
        for proc in process_list:
            # now i need to iterate over the roles and place messages on SNS
            for account, rolearn  in roles:
                thislist = {"rolearn": rolearn, "account": account, "process_item": proc}
                # insert into SNS here
                print ("Message: {}".format(json.dumps(thislist)))
                snsclient = boto3.client('sns')
                topicarn = "arn:aws:sns:us-east-1:987569341137:iso-cloud-auditor"
                snsresponse = snsclient.publish(TopicArn=topicarn, Message=json.dumps(thislist))
                print ("Response: {}".format(snsresponse))
        for proc in process_list:
            # for now, the parent script will fully process the parent account
            # doing this here unblocks the sns message creation, which is this script's primary job
            process_local(cur, proc)
    else:
        # event received -> process it like normal
        # { 'rolearn': arn,
        #   'account': account,
        #   'process_item': item_to_process
        # }
        #print("Received event: " + json.dumps(event, indent=2))
        arn = event['rolearn']
        account = event['account']
        process_item = event['process_item']
        print("Trying AssumeRole ",account, arn )
        client = boto3.client('sts')
        try:
            session = client.assume_role(RoleArn=arn, RoleSessionName='Session' + str(account))
        except:
            print("AssumeRole Failure ",account, arn )
            # update the cross-account-roles table and mark this role as broken
            try:
                cur.execute("UPDATE aws_cross_account_roles set working = %s "
                                        "where role_arn = %s", (False, arn))
            except psycopg2.DatabaseError, exception:
                print (exception)
            # return failure?
            sys.exit(1) 
        process_remote(cur, account, arn, session, process_item)
    #summary_json = main()
    cur.close()
    conn.close()
    return;
