from __future__ import print_function
import argparse
import boto3
import json
import process_instances
import process_roles
import process_groups
import process_users
import process_policies
import psycopg2
import sys, os

def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("-a", "--audit", help="audit [all (default), local, remote] AWS Account(s)")
    args = parser.parse_args()
    if args.audit == "local":
        print("Auditing local")
        audit="local"
    elif args.audit == "remote":
        print("Auditing remote, skipping local")
        audit="remote"
    else:
        print("Auditing all")
        audit="all"
    return audit;

def connect_to_db():
    try:
        connstring = "dbname='" + os.environ('dbname') + "' user='" + os.environ('dbuser') + "' host='" + os.environ('dbhost') + "' password='" + os.environ('dbpass') + "'"
        conn = psycopg2.connect(connstring)
        cur = conn.cursor()
        conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
    except psycopg2.OperationalError as e:
        print ('Database Connection error\n{0}').format(e)
    return cur;

def grab_roles(cur):
    cur.execute("SELECT aws_account_id, role_arn from aws_cross_account_roles")
    roles = cur.fetchall()
    return roles;

def process_remote(cur, account, arn, session):
    # need to accept AssumeRole session variable, grab the keys, and run a 
    #   data collection session
    # Update the cross account table and indicate we've used this account now and it's working
    cur.execute("UPDATE aws_cross_account_roles set working = %s, last_used_ts = %s "
                "where role_arn = %s", (True, "now()", arn))
    thisiam = boto3.client('iam',
        aws_access_key_id=session['Credentials']['AccessKeyId'],
        aws_secret_access_key=session['Credentials']['SecretAccessKey'],
        aws_session_token=session['Credentials']['SessionToken'])

    print("Processing AWS Account ID: " + str(account))
    process_instances.process(thisiam, cur, account)
    process_roles.process(thisiam, cur, account)
    process_users.process(thisiam, cur, account)
    process_groups.process(thisiam, cur, account)
    process_policies.process(thisiam, cur, account)
    return;

def main():
    # main code execution
    # Connect to database
    cur = connect_to_db()
    
    if ((audit == "local") or (audit == "all")):
        # start with the local / default account
        accountid = boto3.client('sts').get_caller_identity()['Account']
        print("Processing AWS Account ID: " + str(accountid))
        thisiam = boto3.client('iam')
        process_instances.process(thisiam, cur, accountid)
        process_roles.process(thisiam, cur, accountid)
        process_users.process(thisiam, cur, accountid)
        process_groups.process(thisiam, cur, accountid)
        process_policies.process(thisiam, cur, accountid)
   
    if ((audit == "remote") or (audit == "all")):
        # process accounts in database
        roles = grab_roles(cur)
        for account, arn  in roles:
            client = boto3.client('sts')
            try:
                session = client.assume_role(RoleArn=arn, RoleSessionName='Session' + str(account))
            except:
                print("Failure ",account, arn )
                continue
            process_remote(cur, account, arn, session)
    
    # clean up
    cur.close()
    conn.close()

def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))
    main()
    return;
